﻿using System;

namespace ArtistStats.Helper
{
	public static class StringHelper
	{
		private static char[] _separator = { ' ' };

		public static int CalculateAverageWordsPerSong(int numberOfSongs, string allWords)
		{
			int totalWordCount = allWords.Split(_separator, StringSplitOptions.RemoveEmptyEntries).Length;

			return totalWordCount / numberOfSongs;
		}
	}
}
