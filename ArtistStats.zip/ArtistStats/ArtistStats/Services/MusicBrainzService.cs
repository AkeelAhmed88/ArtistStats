﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ArtistStats.Interfaces;

namespace ArtistStats.Services
{
	class MusicBrainzService : IMusicBrainzService
	{
		private const string BaseUrl = "https://beta.musicbrainz.org/ws/2/work/";
		private const string UserAgent = "ArtistStats/1.1.0 ( akeelahmed@outlook.com )";

		public MusicBrainzService()
		{
		}

		public async Task<string> GetArtistSongList(string artistName)
		{
			var baseAddress = new Uri(BaseUrl);

			using (HttpClient httpClient = new HttpClient { BaseAddress = baseAddress })
			{
				httpClient.DefaultRequestHeaders.Add("User-Agent", UserAgent);

				using (HttpResponseMessage response = await httpClient.GetAsync($"?query=artist:{artistName}"))
				{
					return await response.Content.ReadAsStringAsync();
				}
			}
		}
	}
}
