﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ArtistStats.Interfaces;
using Newtonsoft.Json.Linq;

namespace ArtistStats.Services
{
	public class LyricsService : ILyricsService
	{
		private const string BaseUrl = "https://api.lyrics.ovh/v1/";
		private const string LyricsToken = "lyrics";

		public LyricsService()
		{
		}

		public async Task<string> GetSongLyricsAsync(string artistName, string songTitle)
		{
			var baseAddress = new Uri(BaseUrl);

			using (HttpClient httpClient = new HttpClient { BaseAddress = baseAddress })
			{
				using (HttpResponseMessage response = await httpClient.GetAsync($"{artistName}/{songTitle}"))
				{
					var jsonObject = await response.Content.ReadAsStringAsync();

					JObject jObject = JObject.Parse(jsonObject);

					return (string)jObject.SelectToken(LyricsToken);
				}
			}
		}
	}
}
