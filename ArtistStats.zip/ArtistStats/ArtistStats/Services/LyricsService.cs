﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ArtistStats.Interfaces;

namespace ArtistStats.Services
{
	public class LyricsService : ILyricsService
	{
		private const string BaseUrl = "https://api.lyrics.ovh/v1/";

		public LyricsService()
		{
		}

		public async Task<string> GetSongLyricsAsync(string artistName, string songTitle)
		{
			var baseAddress = new Uri(BaseUrl);

			using (HttpClient httpClient = new HttpClient { BaseAddress = baseAddress })
			{
				using (HttpResponseMessage response = await httpClient.GetAsync(string.Format("{0}/{1}", artistName, songTitle)))
				{
					return await response.Content.ReadAsStringAsync();
				}
			}
		}
	}
}
