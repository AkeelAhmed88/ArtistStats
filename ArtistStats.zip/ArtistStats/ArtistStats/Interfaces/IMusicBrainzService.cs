﻿using System.Threading.Tasks;

namespace ArtistStats.Interfaces
{
	public interface IMusicBrainzService
	{
		Task<string> GetArtistSongList(string artistName);
	}
}
