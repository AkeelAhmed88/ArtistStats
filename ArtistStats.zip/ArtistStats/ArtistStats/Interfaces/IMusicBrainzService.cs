﻿using System.Threading.Tasks;

namespace ArtistStats.Interfaces
{
	interface IMusicBrainzService
	{
		Task<string> GetArtistSongList(string artistName);
	}
}
