﻿using System.Threading.Tasks;

namespace ArtistStats.Interfaces
{
	public interface ILyricsService
	{
		Task<string> GetSongLyricsAsync(string artistName, string songTitle);
	}
}
