﻿using System.Threading.Tasks;

namespace ArtistStats.Interfaces
{
	interface ILyricsService
	{
		Task<string> GetSongLyricsAsync(string artistName, string songTitle);
	}
}
