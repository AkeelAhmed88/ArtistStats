﻿using System;

namespace ArtistStats
{
	class Program
	{
		private const string Question = "Please entre the artist name:";
		private const string AverageWords = "Average number of words in a song = {0}";

		static void Main()
		{
			InitializeDependencyInjection();

			Console.WriteLine(Question);			

			var artistName = Console.ReadLine();

			if (string.IsNullOrWhiteSpace(artistName))
				Main();

			BusinessLogic averageWords = new BusinessLogic();

			int count = averageWords.GetAverageCountStats(artistName);

			Console.WriteLine(string.Format(AverageWords, count.ToString()));

			Console.ReadLine();
		}

		private static void InitializeDependencyInjection() //Look into dependency injection as I have created interfaces
		{
			throw new NotImplementedException();
		}
	}
}