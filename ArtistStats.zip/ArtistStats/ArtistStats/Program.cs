﻿using System;
using ArtistStats.Interfaces;
using ArtistStats.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ArtistStats
{
	public class Program
	{
		private const string Question = "Please entre the artist name:";		

		public static void Main()
		{
			InitializeDependencyInjection();

			Console.WriteLine(Question);			

			var artistName = Console.ReadLine();

			if (string.IsNullOrWhiteSpace(artistName))
				Main();

			BusinessLogic averageWords = new BusinessLogic(
				lyricsService: LyricsService,
				musicBrainzService: MusicBrainzService);

			int count = averageWords.GetAverageCountStats(artistName);

			Console.WriteLine($"Average number of words in a song = {count}");

			Console.ReadLine();
		}

		private static void InitializeDependencyInjection()
		{
			var serviceCollection = new ServiceCollection();

			ConfigureServices(serviceCollection);

			var serviceProvider = serviceCollection.BuildServiceProvider();

			InitializeServices(serviceProvider);
		}		

		private static void ConfigureServices(IServiceCollection serviceCollection)
		{
			serviceCollection.AddTransient<ILyricsService, LyricsService>();
			serviceCollection.AddTransient<IMusicBrainzService, MusicBrainzService>();
		}

		private static void InitializeServices(ServiceProvider serviceProvider)
		{
			LyricsService = serviceProvider.GetService<ILyricsService>();
			MusicBrainzService = serviceProvider.GetService<IMusicBrainzService>();
		}

		public static ILyricsService LyricsService { get; set; }

		public static IMusicBrainzService MusicBrainzService { get; set; }
	}
}