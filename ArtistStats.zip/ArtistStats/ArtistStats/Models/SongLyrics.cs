﻿namespace ArtistStats.Models
{
	public class SongLyrics
	{
		public string Lyrics { get; set; }
	}
}
