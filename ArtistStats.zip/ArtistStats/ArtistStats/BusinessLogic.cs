﻿using System;
using System.Collections.Generic;
using ArtistStats.Interfaces;
using ArtistStats.Services;

namespace ArtistStats
{
	class BusinessLogic
	{
		private ILyricsService _lyricsService;
		private IMusicBrainzService _musicBrainzService;

		public BusinessLogic() // (ILyricsService lyricsService, IMusicBrainzService musicBrainzService)
		{
			_lyricsService = new LyricsService(); //lyricsService
			_musicBrainzService = new MusicBrainzService(); //musicBrainzService
		}

		internal int GetAverageCountStats(string artistName)
		{
			var artistData = _musicBrainzService.GetArtistSongList(artistName).Result;

			List<string> songList = ExtractSongListFromArtistData(artistData);

			string allWords = string.Empty;

			foreach (string song in songList)
				allWords += _lyricsService.GetSongLyricsAsync(artistName, song).Result;

			return CalculateAverageWordsPerSong(songList.Count, allWords);
		}

		private int CalculateAverageWordsPerSong(int count, string allWords) //move this into helper class
		{
			char[] separator = { ' ' };

			int wordCount = allWords.Split(separator, StringSplitOptions.RemoveEmptyEntries).Length;

			return wordCount / count; //total words divided by number of songs
		}

		private List<string> ExtractSongListFromArtistData(string artistData) //move this into helper class
		{
			throw new NotImplementedException();
		}
	}
}
