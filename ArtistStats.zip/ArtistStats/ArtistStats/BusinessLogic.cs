﻿using System.Collections.Generic;
using System.Xml;
using ArtistStats.Helper;
using ArtistStats.Interfaces;
using Newtonsoft.Json.Linq;

namespace ArtistStats
{
	class BusinessLogic
	{
		private ILyricsService _lyricsService;
		private IMusicBrainzService _musicBrainzService;

		private const string TitleTag = "title";

		public BusinessLogic(ILyricsService lyricsService, IMusicBrainzService musicBrainzService)
		{
			_lyricsService = lyricsService;
			_musicBrainzService = musicBrainzService;
		}

		internal int GetAverageCountStats(string artistName)
		{
			var artistData = _musicBrainzService.GetArtistSongList(artistName).Result;

			List<string> songTitleList = ExtractSongTitleListFromArtistData(artistData);

			string allWords = string.Empty;

			foreach (string songTitle in songTitleList)
				allWords += _lyricsService
						.GetSongLyricsAsync(
							artistName: artistName,
							songTitle: songTitle)
						.Result;

			return StringHelper.CalculateAverageWordsPerSong(
				numberOfSongs: songTitleList.Count, 
				allWords: allWords);
		}

		private List<string> ExtractSongTitleListFromArtistData(string artistData)
		{
			XmlDocument xmlDoc = new XmlDocument();

			xmlDoc.LoadXml(artistData);

			XmlNodeList element = xmlDoc.GetElementsByTagName(TitleTag);

			List<string> sontTitles = new List<string>();

			foreach (XmlNode node in element)
				if (!sontTitles.Contains(node.InnerText))
					sontTitles.Add(node.InnerText);

			return sontTitles.GetRange(1, 5); //limit to fisrt 5 song titles to showcase working code. after performance improvements this can be lifted off
		}
	}
}
